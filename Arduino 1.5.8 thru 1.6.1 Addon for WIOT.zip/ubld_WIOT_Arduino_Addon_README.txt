More information about WIOT at http://WIOT.org

Modified by Chris K Cockrum, Ubld Electronics, LLC. http://ubld.it

For Arduino 1.5.8:

Unzip ubld_WIOT_Arduino_Addon.zip into the arduino directory (i.e. C:\Program Files (x86)\Arduino)
Note: This will overwrite the existing boards.txt   You may need to manually add the WIOT section if you have already installed other hardware Addons