More information about WIOT at http://WIOT.org

Modified by Chris K Cockrum, Ubld Electronics, LLC. http://ubld.it

Notes on building the improved 32u4 Caterina bootloader:

1. Must download LUFA-111009 and extract to this directory.
2. The "build.txt" file and "program.txt" files can be renamed
    to .bat files and run to build and program the boards listed
    herein (Windows only, unfortunately).